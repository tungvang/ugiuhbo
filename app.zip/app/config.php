<?php
//Config Database
define('DB_HOST', 'enter_db_host');
define('DB_USER', 'enter_db_username');
define('DB_PASS', 'enter_db_password');
define('DB_NAME', 'enter_db_name');
define('ENCRYPTION_KEY', 'enter_encryption_key');