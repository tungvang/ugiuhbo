<?php



class autoCompleteUserListResponse extends Response
{
    public $expires;
    /**
     * @var User[]
     */
    public $users;
}
