<?php



class ConfigureResponse extends Response
{
    public $upload_id;
    /**
     * @var Item
     */
    public $media;
}
