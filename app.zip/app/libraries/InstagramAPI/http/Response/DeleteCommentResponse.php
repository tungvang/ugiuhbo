<?php



class DeleteCommentResponse extends Response
{
}
