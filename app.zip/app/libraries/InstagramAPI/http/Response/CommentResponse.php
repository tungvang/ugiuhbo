<?php



class CommentResponse extends Response
{
    public $comment = null;
}
