<?php



class ChallengeResponse extends Response
{
    public $status;
}
