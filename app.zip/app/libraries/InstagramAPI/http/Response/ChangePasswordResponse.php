<?php



class ChangePasswordResponse extends Response
{
}
