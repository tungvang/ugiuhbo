<?php



class AddressBookResponse extends Response
{
    /**
     * @var Suggestion[]
     */
    public $items;
}
