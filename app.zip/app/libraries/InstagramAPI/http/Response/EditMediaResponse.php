<?php



class EditMediaResponse extends Response
{
    /**
     * @var Item
     */
    public $media;
}
