<?php



class CommentLikeUnlikeResponse extends Response
{
}
